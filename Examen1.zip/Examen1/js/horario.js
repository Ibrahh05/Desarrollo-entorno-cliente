function generarHorarios() {
            let html = "<h3>Horario Mañana</h3><table>";
            html += "<tr><th>Hora</th><th>L</th><th>M</th><th>X</th><th>J</th><th>V</th></tr>";
            
            for (let h = 9; h <= 13; h += 2) {
                html += "<tr><th>" + h + ":00-" + (h+2) + ":00</th>";
                for (let d = 0; d < 5; d++) {
                    html += "<td>X</td>";
                }
                html += "</tr>";
            }
            html += "</table>";

            html += "<h3>Horario Tarde</h3><table>";
            html += "<tr><th>Hora</th><th>L</th><th>M</th><th>X</th><th>J</th><th>V</th><th>S</th><th>D</th></tr>";
            
            for (let h = 16; h <= 20; h++) {
                html += "<tr><th>" + h + ":00-" + (h+1) + ":00</th>";
                for (let d = 0; d < 7; d++) {
                    html += "<td>X</td>";
                }
                html += "</tr>";
            }
            html += "</table>";

            document.getElementById("horarios").innerHTML = html;
        }